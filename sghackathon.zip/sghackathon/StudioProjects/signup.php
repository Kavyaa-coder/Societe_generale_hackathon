<?php
// signup.php

// Connect to database
$conn = mysqli_connect("localhost", "username", "password", "database");

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $fname = $_POST["fname"];
  $lname = $_POST["lname"];
  $dob = $_POST["dob"];
  $uname = $_POST["uname"];
  $pwd = $_POST["pwd"];
  $mail = $_POST["mail"];

  // Insert data into database
  $sql = "INSERT INTO users (fname, lname, dob, uname, pwd, mail) VALUES ('$fname', '$lname', '$dob', '$uname', '$pwd', '$mail')";
  if (mysqli_query($conn, $sql)) {
    header('Location: login.php');
    exit;
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
}

mysqli_close($conn);
?>