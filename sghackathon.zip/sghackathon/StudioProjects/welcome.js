const rocket = document.getElementById('rocket');
const goButton = document.getElementById('go-button');

// Add event listeners to move the rocket
document.addEventListener('keydown', (e) => {
	if (e.key === 'ArrowUp') {
		rocket.style.top = `${parseInt(rocket.style.top) - 10}px`;
	} else if (e.key === 'ArrowDown') {
		rocket.style.top = `${parseInt(rocket.style.top) + 10}px`;
	} else if (e.key === 'ArrowLeft') {
		rocket.style.left = `${parseInt(rocket.style.left) - 10}px`;
	} else if (e.key === 'ArrowRight') {
		rocket.style.left = `${parseInt(rocket.style.left) + 10}px`;
	}
});

// Add event listener to the button
document.addEventListener("DOMContentLoaded", function() {
    const goButton = document.getElementById("go-button");
    goButton.addEventListener("click", function() {
      window.location.href = "python.html";
    });
  });