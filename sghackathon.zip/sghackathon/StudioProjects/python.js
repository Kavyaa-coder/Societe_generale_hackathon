document.addEventListener("DOMContentLoaded", function() {
    const goButton = document.getElementById("go-button");
    goButton.addEventListener("click", function() {
      window.location.href = "levels.html";
    });
  
    const dragDropZone = document.querySelector(".drag-drop-zone");
    const blanks = document.querySelectorAll(".blank");
    const letters = document.querySelectorAll(".letter");
  
    letters.forEach((letter) => {
      letter.addEventListener("dragstart", (e) => {
        e.dataTransfer.setData("text", letter.id);
      });
    });
  
    dragDropZone.addEventListener("dragover", (e) => {
      e.preventDefault();
    });
  
    dragDropZone.addEventListener("drop", (e) => {
      e.preventDefault();
      const letterId = e.dataTransfer.getData("text");
      const letter = document.getElementById(letterId);
      const blank = getBlankUnderMouse(e.clientX, e.clientY);
      if (blank) {
        blank.appendChild(letter);
      }
    });
  
    function getBlankUnderMouse(x, y) {
      for (const blank of blanks) {
        const rect = blank.getBoundingClientRect();
        if (x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom) {
          return blank;
        }
      }
      return null;
    }
  });