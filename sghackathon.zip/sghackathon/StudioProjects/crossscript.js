// Example crossword grid data (1 represents black squares)
const grid = [
    [1, 1, 1, 1, 1, 1, 0, 1],
    [0, 0, 0, 0, 0, 0, 0, 0],
    [1, 1, 1, 1, 0, 1, 0, 1],
    [1, 1, 1, 1, 0, 1, 1, 1],
    [1, 0, 0, 0, 0, 1, 1, 1],
    [1, 1, 1, 1, 0, 1, 1, 1]
    
];

// Example questions and clues
const questions = [
    { number: 1, row: 0, col: 6, direction: 'down', question: 'How do you remove the last element from an array? (Down)', answer: 'pop' },
    { number: 2, row: 1, col: 0, direction: 'across', question: 'What is the method inside the class in python language? (across)', answer: 'function' },
    { number: 3, row: 1, col: 4, direction: 'down', question: 'What is the output of len(myArray) if myArray is an array with 3 elements?(down)', answer: 'three' },
    { number: 4, row: 4, col: 1, direction: 'across', question: 'What will be the output of this function?round(4.576)(across)', answer: 'five' },
   
];

// Track user answers
let userAnswers = {};

// Function to generate crossword grid
function generateGrid() {
    const puzzle = document.getElementById('puzzle');
    const questionsContainer = document.getElementById('questions');
    const submitBtn = document.getElementById('submit-btn');
    const scoreValue = document.getElementById('score-value');

    puzzle.innerHTML = ''; // Clear previous content
    questionsContainer.innerHTML = ''; // Clear previous questions

    for (let i = 0; i < grid.length; i++) {
        for (let j = 0; j < grid[i].length; j++) {
            const cell = document.createElement('div');
            cell.classList.add('cell');
            if (grid[i][j] === 1) {
                cell.classList.add('black');
            } else {
                // Initialize with empty text input
                const input = document.createElement('input');
                input.type = 'text';
                input.maxLength = 1;
                input.classList.add('input-cell');
                input.dataset.row = i;
                input.dataset.col = j;
                input.addEventListener('input', function() {
                    // Store user answer
                    const key = `${input.dataset.row}-${input.dataset.col}`;
                    userAnswers[key] = input.value.toUpperCase(); // Store uppercase letter
                });
                cell.appendChild(input);

                // Check if there's a question for this cell
                const question = questions.find(q => q.row === i && q.col === j);
                if (question) {
                    cell.dataset.question = question.question;
                    cell.dataset.answer = question.answer;
                    cell.classList.add('has-question');

                    // Display number in the cell
                    const number = document.createElement('div');
                    number.classList.add('number');
                    number.textContent = question.number;
                    cell.appendChild(number);
                }
            }

            puzzle.appendChild(cell);
        }
    }

    // Display questions below the grid
    questions.forEach(question => {
        const questionText = document.createElement('div');
        questionText.textContent = `${question.number}. ${question.question}`;
        questionsContainer.appendChild(questionText);
    });

    // Add submit functionality
    submitBtn.addEventListener('click', function() {
        let score = 0;
        Object.keys(userAnswers).forEach(key => {
            const [row, col] = key.split('-');
            const answer = userAnswers[key];
            const correctAnswer = grid[row][col];
            if (correctAnswer !== 1 && answer === correctAnswer.toUpperCase()) {
                score++;
            }
        });
        scoreValue.textContent = score;
        alert(`Your score: ${score}/${questions.length}`);
    });
}

// Call the function to generate the crossword grid on page load
document.addEventListener('DOMContentLoaded', generateGrid);
