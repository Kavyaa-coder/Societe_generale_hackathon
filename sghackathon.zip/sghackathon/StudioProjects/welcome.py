import pygame
import random

# Initialize Pygame
pygame.init()

# Set screen dimensions
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))

# Set title
#pygame.display.set_caption("Rocket Quest")

# Load rocket image
rocket_image = pygame.image.load("rocket.png").convert_alpha()
rocket_rect = rocket_image.get_rect()

if rocket_rect.width > screen_width:
    rocket_rect.width = screen_width
if rocket_rect.height > screen_height:
    rocket_rect.height = screen_height

# Set initial rocket position
rocket_rect.x = random.randint(0, screen_width - rocket_rect.width)
rocket_rect.y = random.randint(0, screen_height - rocket_rect.height)

# Load EDD logo image
edd_logo_image = pygame.image.load("edd_logo.jpg").convert_alpha()
edd_logo_rect = edd_logo_image.get_rect()
edd_logo_rect.x = 10
edd_logo_rect.y = 10

# Set initial rocket position
rocket_rect.x = random.randint(0, screen_width - rocket_rect.width)
rocket_rect.y = random.randint(0, screen_height - rocket_rect.height)

# Set rocket speed
rocket_speed = 10

# Set font for text
font = pygame.font.Font(None, 36)

# Set text colors
text_color = (255, 255, 255)  # White
highlight_color = (255, 0, 0)  # Red

# Set text positions
quest_for_code_surface = font.render("QUEST FOR CODE", True, text_color)
quest_for_code_rect = quest_for_code_surface.get_rect()
quest_for_code_rect.x = 200
quest_for_code_rect.y = 50

lets_go_surface = font.render("LET's Go!!", True, highlight_color)
lets_go_rect = lets_go_surface.get_rect()
lets_go_rect.x = 300
lets_go_rect.y = 100
# Game loop
running = True
while running:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Move rocket randomly
    rocket_rect.x += random.randint(-rocket_speed, rocket_speed)
    rocket_rect.y += random.randint(-rocket_speed, rocket_speed)

    # Keep rocket within screen bounds
    if rocket_rect.left < 0:
        rocket_rect.left = 0
    if rocket_rect.right > screen_width:
        rocket_rect.right = screen_width
    if rocket_rect.top < 0:
        rocket_rect.top = 0
    if rocket_rect.bottom > screen_height:
        rocket_rect.bottom = screen_height

    # Clear the screen
    screen.fill((0, 0, 0))  # Black background

    # Draw EDD logo
    screen.blit(edd_logo_image, edd_logo_rect)

    # Draw text
    screen.blit(quest_for_code_surface, quest_for_code_rect)
    screen.blit(lets_go_surface, lets_go_rect)

    # Draw rocket
    screen.blit(rocket_image, rocket_rect)

    # Update the display
    pygame.display.flip()

# Quit Pygame
pygame.quit()
